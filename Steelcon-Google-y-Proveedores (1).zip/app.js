const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
let data={articles:[],quotes:[]},offers=[],selectedOffer=null,connected=false;
const normalize=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
function findCatalog(query){const terms=normalize(query).split(' ').filter(Boolean);if(!terms.length)return [];return data.articles.map(a=>{const desc=normalize(a.description),code=normalize(a.code),full=code+' '+desc;const hit=terms.every(t=>full.includes(t));const score=(code===normalize(query)?100:0)+(code.startsWith(normalize(query))?40:0)+(desc.includes(normalize(query))?30:0);return {a,hit,score};}).filter(x=>x.hit).sort((x,y)=>y.score-x.score||x.a.description.localeCompare(y.a.description)).slice(0,50).map(x=>x.a)}
function catalogSearch(query){const list=findCatalog(query);$('#catalog-count').textContent=list.length+(list.length===50?'+':'')+' coincidencias';$('#catalog-results').className=list.length?'':'empty compact';$('#catalog-results').innerHTML=list.length?list.map(a=>`<div class="catalog-item"><div><strong>${h(a.code||'Sin código')}</strong><span>${h(a.description)}</span><small>${h(a.unit||'unid.')}</small></div><button class="outline" data-catalog-query="${h(a.description)}">Consultar precio</button></div>`).join(''):(query.trim()?'No se encontraron coincidencias en tu catálogo. Podés importar un CSV desde Artículos.':'Escribí un código STE o descripción para buscar dentro del catálogo.');}
function externalSearch(query){const box=$('#market-links');box.hidden=!query.trim();if(!query.trim())return;const q=encodeURIComponent(query),country=$('#country').value;const selected=suppliers.find(x=>x.id===$('#supplier-filter').value);const restrict=selected?' '+(selected.url?'site:'+new URL(selected.url).hostname:selected.name):'';const restricted=encodeURIComponent(query+restrict);const urls=[...(selected?[{name:'Buscar '+selected.name+' en Google',url:`https://www.google.com/search?gl=${country}&q=${restricted}`}]:[]),{name:'Ver precios en Google Shopping',url:`https://www.google.com/search?tbm=shop&gl=${country}&q=${q}`},{name:'Buscar en Google',url:`https://www.google.com/search?gl=${country}&q=${q}`}];$('#external-links').innerHTML=urls.map(x=>`<a href="${h(x.url)}" target="_blank" rel="noopener noreferrer">${h(x.name)} ↗</a>`).join('');}

const fmtDate=s=>new Date(s).toLocaleString('es-PY',{dateStyle:'short',timeStyle:'short'});
const h=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=(n,c)=>new Intl.NumberFormat('es-PY',{maximumFractionDigits:c==='PYG'?0:2}).format(n)+' '+c;
const err=e=>alert(e.message||String(e));
const STORAGE_KEY='steelcon-precios-web-v1';
const SUPPLIERS_KEY='steelcon-suppliers-v1';
let suppliers=[];
function loadSuppliers(){try{const v=JSON.parse(localStorage.getItem(SUPPLIERS_KEY)||'[]');return Array.isArray(v)?v:[]}catch{return []}}
function saveSuppliers(){localStorage.setItem(SUPPLIERS_KEY,JSON.stringify(suppliers));renderSuppliers()}
function renderSuppliers(){const sel=$('#supplier-filter'),chosen=sel.value;sel.innerHTML='<option value="">Todos los proveedores</option>'+suppliers.map(x=>`<option value="${h(x.id)}">${h(x.name)}</option>`).join('');sel.value=suppliers.some(x=>x.id===chosen)?chosen:'';$('#supplier-list').innerHTML=suppliers.length?`<table class="simple-table"><thead><tr><th>PROVEEDOR</th><th>SITIO WEB</th><th>ACCIONES</th></tr></thead><tbody>${suppliers.map(x=>`<tr><td>${h(x.name)}</td><td>${x.url?`<a href="${h(x.url)}" target="_blank" rel="noopener noreferrer">Visitar sitio ↗</a>`:'—'}</td><td><button data-select-supplier="${h(x.id)}">Buscar precios</button> <button data-delete-supplier="${h(x.id)}">Eliminar</button></td></tr>`).join('')}</tbody></table>`:'<div class="empty">Todavía no hay proveedores. Agregá el primero arriba.</div>';}

function getDB(){try{let v=JSON.parse(localStorage.getItem(STORAGE_KEY));return {articles:Array.isArray(v.articles)?v.articles:[],quotes:Array.isArray(v.quotes)?v.quotes:[]};}catch{return {articles:[],quotes:[]}}}
function writeDB(db){localStorage.setItem(STORAGE_KEY,JSON.stringify(db));}
function uid(){return (globalThis.crypto?.randomUUID?.()||Date.now()+'-'+Math.random());}
async function api(url,options={}){
 const db=getDB();const method=options.method||'GET';const p=options.body?JSON.parse(options.body):{};
 if(url==='/api/status')return {connected:false};
 if(url==='/api/data')return db;
 if(url==='/api/articles' && method==='POST'){
  if(!String(p.description||'').trim())throw Error('Ingresá la descripción del artículo.');
  const a={id:uid(),code:String(p.code||'').trim(),description:String(p.description).trim(),unit:String(p.unit||'unid.').trim(),createdAt:new Date().toISOString()};db.articles.unshift(a);writeDB(db);return a;
 }
 if(url.startsWith('/api/articles/') && method==='DELETE'){const id=decodeURIComponent(url.split('/').pop());db.articles=db.articles.filter(a=>a.id!==id);db.quotes=db.quotes.filter(q=>q.articleId!==id);writeDB(db);return {ok:true};}
 if(url==='/api/quotes' && method==='POST'){
  if(!db.articles.some(a=>a.id===p.articleId))throw Error('Seleccioná un artículo.');
  const amount=Number(p.amount);if(!Number.isFinite(amount)||amount<0||!String(p.supplier||'').trim())throw Error('Proveedor y precio válido son obligatorios.');
  const q={id:uid(),articleId:p.articleId,supplier:String(p.supplier).trim(),amount,currency:['PYG','USD','BRL','ARS'].includes(p.currency)?p.currency:'PYG',url: /^https?:\/\//i.test(String(p.url||''))?p.url:'',source:p.source||'Cotización manual',observedAt:new Date().toISOString()};db.quotes.unshift(q);writeDB(db);return q;
 }
 if(url.startsWith('/api/quotes/') && method==='DELETE'){const id=decodeURIComponent(url.split('/').pop());db.quotes=db.quotes.filter(q=>q.id!==id);writeDB(db);return {ok:true};}
 throw Error('Acción no disponible');
}
const post=(url,obj)=>api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)});
async function refresh(){data=await api('/api/data');render();catalogSearch($('#query').value);}
function render(){
 $('#m-articles').textContent=data.articles.length;$('#m-quotes').textContent=data.quotes.length;
 const opts='<option value="">Seleccionar artículo</option>'+data.articles.map(a=>`<option value="${h(a.id)}">${h(a.code)} ${h(a.description)}</option>`).join('');$('#qarticle').innerHTML=opts;$('#save-article').innerHTML=opts;
 $('#article-list').innerHTML=data.articles.length?`<div class="scroll"><table class="simple-table"><thead><tr><th>CÓDIGO</th><th>DESCRIPCIÓN</th><th>UNIDAD</th><th>ACCIONES</th></tr></thead><tbody>${data.articles.map(a=>`<tr><td>${h(a.code||'—')}</td><td>${h(a.description)}</td><td>${h(a.unit)}</td><td><button data-delete-article="${h(a.id)}">Eliminar</button> <button data-query="${h(a.description)}" style="color:#009879">Buscar</button></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">Todavía no hay artículos. Cargá uno arriba o importá un CSV.</div>';
 $('#quotes-list').innerHTML=data.quotes.length?`<div class="scroll"><table class="simple-table"><thead><tr><th>ARTÍCULO</th><th>PROVEEDOR</th><th>PRECIO</th><th>FECHA</th><th>ENLACE</th><th></th></tr></thead><tbody>${data.quotes.map(q=>{const a=data.articles.find(a=>a.id===q.articleId);return `<tr><td>${h(a?.code||'')} ${h(a?.description||'')}</td><td>${h(q.supplier)}</td><td><strong>${money(q.amount,q.currency)}</strong></td><td>${fmtDate(q.observedAt)}</td><td>${q.url?`<a href="${h(q.url)}" target="_blank" rel="noopener noreferrer">Ver ↗</a>`:'—'}</td><td><button data-delete-quote="${h(q.id)}">Eliminar</button></td></tr>`}).join('')}</tbody></table></div>`:'<div class="empty">No hay cotizaciones guardadas.</div>';
}
function setTab(tab){$$('.tab').forEach(e=>e.classList.toggle('active',e.id===tab));$$('.nav').forEach(e=>e.classList.toggle('active',e.dataset.tab===tab));}
$$('.nav').forEach(n=>n.onclick=()=>setTab(n.dataset.tab));
$('#today').textContent=new Date().toLocaleDateString('es-PY',{day:'2-digit',month:'short',year:'numeric'});
async function check(){
 try{
  const r=await fetch('/.netlify/functions/precios',{method:'GET',cache:'no-store'});
  const type=r.headers.get('content-type')||'';
  if(!type.includes('application/json'))throw Error('La función de Netlify no está publicada (respuesta HTTP '+r.status+').');
  const status=await r.json();
  connected=!!(r.ok&&status.configured);
  $('#side-status').textContent=connected?'Buscador de mercado conectado':(status.error||'No hay conexión al buscador');
  $('#m-connection').textContent=connected?'Activo':r.status===404?'Sin función':'Sin clave';
  $('#m-sub').textContent=connected?'Resultados publicados al consultar':(status.error||'Revisá la publicación y SERPAPI_KEY');
  if(!connected)showFeedback(status.error||'La función no está configurada. Publicá este proyecto mediante Git en Netlify y agregá SERPAPI_KEY. El catálogo local sigue disponible.');
 }catch(e){connected=false;
  $('#side-status').textContent='Buscador no disponible';$('#m-connection').textContent='Sin conexión';
  $('#m-sub').textContent='No se encuentra la función web';showFeedback(e.message+' Publicá el proyecto completo por Git en Netlify.');
 }
}
async function search(){
 const query=$('#query').value.trim();catalogSearch(query);externalSearch(query);if(query.length<3){showFeedback('Ingresá una descripción de al menos 3 caracteres.');return;}
 // Consultar siempre al servidor: una comprobación inicial fallida no debe bloquear nuevos intentos.
 const country=$('#country').value;$('#search').disabled=true;$('#search').textContent='Buscando…';$('#result-count').textContent='Consultando el mercado';
 $('#results').classList.remove('empty');$('#results').innerHTML='<div class="empty">Buscando precios publicados por los comercios…</div>';
 try{const res=await fetch('/.netlify/functions/precios?q='+encodeURIComponent(query)+'&country='+encodeURIComponent(country),{cache:'no-store'});
 const type=res.headers.get('content-type')||'';if(!type.includes('application/json'))throw Error('La función de búsqueda no está publicada en Netlify. Volvé a desplegar el proyecto completo por Git.');const json=await res.json();if(!res.ok)throw Error(json.error||'No se pudo consultar el servicio.');
 connected=true;$('#side-status').textContent='Buscador de Google Shopping conectado';$('#m-connection').textContent='Activo';offers=Array.isArray(json.offers)?json.offers:[];const chosenSupplier=suppliers.find(x=>x.id===$('#supplier-filter').value);if(chosenSupplier){const host=chosenSupplier.url?new URL(chosenSupplier.url).hostname.replace(/^www\./,''):'';offers=offers.filter(o=>normalize(o.supplier).includes(normalize(chosenSupplier.name))||(host&&o.url&&(()=>{try{return new URL(o.url).hostname.replace(/^www\./,'').endsWith(host)}catch{return false}})()));}$('#result-count').textContent=offers.length+' ofertas · '+new Date(json.checkedAt).toLocaleString('es-PY');renderOffers();
 showFeedback(offers.length?'Consulta realizada. Precios publicados por terceros; verificá stock, impuestos y vigencia antes de comprar. Los resultados pueden no coincidir exactamente con la medida buscada.':'No se encontraron ofertas visibles para esta descripción o proveedor. Google Shopping puede no publicar precios de este proveedor; probá Todos los proveedores o el enlace de búsqueda Google.');
 }catch(e){offers=[];$('#result-count').textContent='Consulta no disponible';$('#results').innerHTML='<div class="empty">No fue posible obtener precios en este momento.</div>';showFeedback('Búsqueda Google: '+e.message+' Si no configuraste SERPAPI_KEY, agregala a Netlify y volvé a publicar.');}
 finally{$('#search').disabled=false;$('#search').textContent='Buscar precios →';}
}
$('#add-supplier').onsubmit=e=>{e.preventDefault();const name=$('#supplier-name').value.trim();let url=$('#supplier-url').value.trim();if(url&&!/^https?:\/\//i.test(url))url='https://'+url;try{if(url){const u=new URL(url);if(!['https:','http:'].includes(u.protocol))throw Error('Sitio inválido');url=u.href;}if(!name)throw Error('Ingresá un nombre');suppliers.push({id:uid(),name,url});saveSuppliers();e.target.reset()}catch(ex){err(ex)}};document.addEventListener('click',e=>{const del=e.target.closest('[data-delete-supplier]');if(del&&confirm('¿Eliminar proveedor?')){suppliers=suppliers.filter(x=>x.id!==del.dataset.deleteSupplier);saveSuppliers()}const pick=e.target.closest('[data-select-supplier]');if(pick){setTab('panel');$('#supplier-filter').value=pick.dataset.selectSupplier;$('#query').focus();externalSearch($('#query').value)}});$('#supplier-filter').addEventListener('change',()=>externalSearch($('#query').value));suppliers=loadSuppliers();renderSuppliers();
function showFeedback(s){$('#feedback').textContent=s;$('#feedback').classList.remove('hidden')}
function renderOffers(){const el=$('#results');if(!offers.length){el.innerHTML='<div class="empty">No hay resultados para esta búsqueda.</div>';return;}el.classList.remove('empty');el.innerHTML=offers.map((x,i)=>`<div class="result"><div><strong>${h(x.title)}</strong><div class="source">${h(x.supplier||'Proveedor sin identificar')} ${x.delivery?'· '+h(x.delivery):''}</div></div><div class="price">${h(x.price||'Precio no disponible')}</div><div class="actions">${x.url?`<a href="${h(x.url)}" target="_blank" rel="noopener noreferrer">Ver tienda ↗</a>`:''}<button class="outline" data-save="${i}">+ Guardar</button></div></div>`).join('');}
$('#query').addEventListener('input',e=>{catalogSearch(e.target.value);externalSearch(e.target.value)});$('#search').onclick=search;$('#query').addEventListener('keydown',e=>{if(e.key==='Enter')search()});$$('[data-search]').forEach(b=>b.onclick=()=>{$('#query').value=b.dataset.search;search();});
document.addEventListener('click',async e=>{
 const c=e.target.closest('[data-catalog-query]');if(c){$('#query').value=c.dataset.catalogQuery;setTab('panel');search();}
 const a=e.target.closest('[data-query]');if(a){$('#query').value=a.dataset.query;setTab('panel');search();}
 const s=e.target.closest('[data-save]');if(s){selectedOffer=offers[Number(s.dataset.save)];$('#modal-title').textContent=selectedOffer.title;$('#save-supplier').value=selectedOffer.supplier;$('#save-amount').value=selectedOffer.amount??'';$('#save-currency').value=['PYG','USD','BRL','ARS'].includes(selectedOffer.currency)?selectedOffer.currency:'PYG';if(!selectedOffer.currency)alert('La moneda de esta oferta no pudo identificarse. Verificá manualmente moneda y precio antes de guardar.');const matched=data.articles.find(a=>selectedOffer.title.toLowerCase().includes(a.description.toLowerCase()));$('#save-article').value=matched?.id||'';$('#save-dialog').showModal();}
 const da=e.target.closest('[data-delete-article]');if(da&&confirm('¿Eliminar el artículo y todas sus cotizaciones?')){try{await api('/api/articles/'+encodeURIComponent(da.dataset.deleteArticle),{method:'DELETE'});refresh();}catch(ex){err(ex)}}
 const dq=e.target.closest('[data-delete-quote]');if(dq&&confirm('¿Eliminar esta cotización?')){try{await api('/api/quotes/'+encodeURIComponent(dq.dataset.deleteQuote),{method:'DELETE'});refresh();}catch(ex){err(ex)}}
});
$('#close-dialog').onclick=()=>$('#save-dialog').close();
$('#save-result').onsubmit=async e=>{e.preventDefault();try{await post('/api/quotes',{articleId:$('#save-article').value,supplier:$('#save-supplier').value,amount:$('#save-amount').value,currency:$('#save-currency').value,url:selectedOffer.url,source:'Búsqueda web en vivo'});$('#save-dialog').close();await refresh();setTab('quotes');}catch(ex){err(ex)}};
$('#add-article').onsubmit=async e=>{e.preventDefault();try{await post('/api/articles',{code:$('#acode').value,description:$('#adesc').value,unit:$('#aunit').value});$('#acode').value='';$('#adesc').value='';await refresh();}catch(ex){err(ex)}};
$('#add-quote').onsubmit=async e=>{e.preventDefault();try{await post('/api/quotes',{articleId:$('#qarticle').value,supplier:$('#qsupplier').value,amount:$('#qamount').value,currency:$('#qcurrency').value,url:$('#qurl').value});e.target.reset();await refresh();}catch(ex){err(ex)}};
function parseCSV(text){const rows=[];let row=[],field='',quoted=false;for(let i=0;i<text.length;i++){let c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){field+='"';i++}else quoted=!quoted;}else if(c===','&&!quoted){row.push(field);field=''}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(field);if(row.some(x=>x.trim()))rows.push(row);row=[];field='';}else field+=c;}row.push(field);if(row.some(x=>x.trim()))rows.push(row);return rows;}
$('#csv').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{let txt=await f.text();txt=txt.replace(/^\uFEFF/,'');const first=txt.split(/\r?\n/)[0];if((first.match(/;/g)||[]).length>(first.match(/,/g)||[]).length)txt=txt.replace(/;/g,',');const rows=parseCSV(txt);if(!rows.length)throw Error('Archivo vacío');const header=rows[0].map(x=>x.toLowerCase().trim());let code=header.findIndex(x=>/c[oó]digo|^cod$|sku/.test(x)),desc=header.findIndex(x=>/descrip|art[ií]culo|producto|material/.test(x)),unit=header.findIndex(x=>/unidad|^und$/.test(x));const recognized=desc>=0;const content=recognized?rows.slice(1):rows;code=recognized?code:0;desc=recognized?desc:1;unit=recognized?unit:2;let done=0,failed=0;for(const row of content.slice(0,500)){if(!row[desc]?.trim())continue;try{await post('/api/articles',{code:row[code]||'',description:row[desc],unit:row[unit]||'unid.'});done++;}catch{failed++;}}await refresh();alert(`Importados: ${done}. Fallidos: ${failed}. Límite por archivo: 500 filas.`);}catch(ex){err(ex)}finally{e.target.value='';}};
$('#export').onclick=()=>{const rows=[['Código','Descripción','Proveedor','Precio','Moneda','Fecha','Fuente','URL'],...data.quotes.map(q=>{const a=data.articles.find(a=>a.id===q.articleId);return[a?.code||'',a?.description||'',q.supplier,q.amount,q.currency,q.observedAt,q.source,q.url]})];const csv='\uFEFF'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');const file=new Blob([csv],{type:'text/csv;charset=utf-8'}),u=URL.createObjectURL(file),a=document.createElement('a');a.href=u;a.download='steelcon-cotizaciones.csv';a.click();URL.revokeObjectURL(u);};
Promise.all([refresh(),check()]).catch(err);
