const COUNTRIES={py:{gl:'py',hl:'es'},ar:{gl:'ar',hl:'es'},br:{gl:'br',hl:'pt'},us:{gl:'us',hl:'en'}};
const allowedOrigins = {'PYG':'PYG','₲':'PYG','USD':'USD','US$':'USD','$':'USD','BRL':'BRL','R$':'BRL','ARS':'ARS'};
function currencyFromPrice(item,country){
 const price=String(item.price||'');
 if(/₲|\bPYG\b|\bGs\.?\b/i.test(price))return 'PYG';
 if(/R\$|\bBRL\b/i.test(price))return 'BRL';
 if(/US\$|\bUSD\b/i.test(price))return 'USD';
 if(/\bARS\b/i.test(price))return 'ARS';
 if(price.includes('$'))return country==='ar'?'ARS':country==='us'?'USD':null;
 return null;
}
export default async function handler(request){
 const cors={'Access-Control-Allow-Origin':'*','Cache-Control':'no-store','Content-Type':'application/json;charset=utf-8'};
 const respond=(v,status=200)=>new Response(JSON.stringify(v),{status,headers:cors});
 const key=process.env.SERPAPI_KEY;
 if(!key)return respond({configured:false,error:'Falta configurar SERPAPI_KEY en las variables de entorno de Netlify.'},request.url.includes('?')?503:200);
 const input=new URL(request.url),q=(input.searchParams.get('q')||'').trim();
 if(!q)return respond({configured:true});
 if(q.length<3||q.length>180)return respond({error:'La descripción debe tener entre 3 y 180 caracteres.'},400);
 const country=(input.searchParams.get('country')||'py').toLowerCase(),region=COUNTRIES[country];
 if(!region)return respond({error:'País no permitido'},400);
 try{
 const url=new URL('https://serpapi.com/search.json');
 for(const [k,v] of Object.entries({engine:'google_shopping',q,gl:region.gl,hl:region.hl,num:'30',api_key:key}))url.searchParams.set(k,v);
 const ac=new AbortController(),tm=setTimeout(()=>ac.abort(),19000);
 let response;try{response=await fetch(url,{signal:ac.signal})}finally{clearTimeout(tm)}
 const json=await response.json();
 if(!response.ok||json.error)return respond({error:json.error||'El servicio de búsqueda rechazó la consulta.'},502);
 const offers=(json.shopping_results||[]).map(x=>{
 const amount=Number(x.extracted_price),currency=currencyFromPrice(x,country);
 return {title:String(x.title||'').slice(0,300),supplier:String(x.source||'Proveedor sin identificar').slice(0,140),price:String(x.price||'').slice(0,100),amount:Number.isFinite(amount)&&amount>0?amount:null,currency,delivery:String(x.delivery||'').slice(0,140),url:String(x.product_link||x.link||'').startsWith('https://')?String(x.product_link||x.link):''};
 }).filter(x=>x.title&&x.price&&x.amount!==null);
 return respond({configured:true,checkedAt:new Date().toISOString(),query:q,country,offers});
 }catch(e){return respond({error:e.name==='AbortError'?'La consulta superó el tiempo de espera.':'No se pudo consultar el buscador de mercado.'},502)}
}
